(***********************************)
(* Part 1: Non-Recursive Functions *)
(***********************************)

let rev_tup tup = match tup with
(a,b,c) -> (c,b,a)

let is_odd x = if x mod 2 = 0 then false else true

let area x y = let (a,b) = x in let (c,d) = y in abs ((c-a)*(d-b))

let volume x y = let (a,b,c) = x in let (d, e, f) = y in abs ((d-a)*(e-b)*(f-c))

(*******************************)
(* Part 2: Recursive Functions *)
(*******************************)

let rec fibonacci n = match n with
0 -> 0
| 1 -> 1
| x -> fibonacci (x - 1) + fibonacci (x-2) 

let rec pow x y = match y with
0 -> 1
| z -> x * pow x (z - 1) 

let rec log x y = match y/x with 
0 -> 0
| z -> 1 + log x z

let rec gcf x y = 
if x = 0 then y 
else if y = 0 then x
else if x = y then x
else if x > y then gcf (x-y) y
else gcf x (y-x)

let rec is_prime_aux x i = 
if x < 2 then false
else if x = 2 then true 
else if x mod i = 0 then false
else if x < (i * i) then true
else is_prime_aux x (i + 1)


let rec is_prime x = is_prime_aux x 2



(*****************)
(* Part 3: Lists *)
(*****************)

let rec get idx lst = match lst with
[] -> failwith "Out of bounds"
|h::t -> if idx = 0 then h else get (idx - 1) t

let rec length lst = match lst with
[] -> 0
|h::t -> 1 + length t

let larger lst1 lst2 = 
if length lst1 > length lst2 then lst1 
else if length lst1 < length lst2 then lst2
else []

let rec combine lst1 lst2 = match lst1 with
[] -> lst2
|h::t -> h :: combine t lst2 

let rec reverse lst = match lst with
[] -> []
|h::t -> combine (reverse t) [h]

let rec merge lst1 lst2 = match lst1 with
[] -> lst2
|h::t -> match lst2 with 
[] -> lst1 
| h'::t' -> 
if h < h' then combine [h] (merge t lst2) 
else combine [h'] (merge lst1 t')

let rec rotate_aux count shift lst = 
if count = length lst then [] 
else get (shift mod length lst) lst :: rotate_aux (count + 1) (shift + 1) lst

let rec rotate shift lst = rotate_aux 0 shift lst

let rec is_palindrome_aux lst count = 
if count = length lst then true
else if (get count lst) <> (get (length lst - count - 1) lst) then false
else is_palindrome_aux lst (count + 1)

let rec is_palindrome lst = is_palindrome_aux lst 0