#! /bin/sh
. ./ocaml_version.sh
dune exec bin/viz.bc
