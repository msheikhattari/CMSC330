open List
open Sets

(*********)
(* Types *)
(*********)

type ('q, 's) transition = 'q * 's option * 'q

type ('q, 's) nfa_t = {
  sigma: 's list;
  qs: 'q list;
  q0: 'q;
  fs: 'q list;
  delta: ('q, 's) transition list;
}

(***********)
(* Utility *)
(***********)

(* explode converts a string to a character list *)
let explode (s: string) : char list =
  let rec exp i l =
    if i < 0 then l else exp (i - 1) (s.[i] :: l)
  in
  exp (String.length s - 1) []

(****************)
(* Part 1: NFAs *)
(****************)

let move (nfa: ('q,'s) nfa_t) (qs: 'q list) (s: 's option) : 'q list = 
  List.sort_uniq Stdlib.compare (List.fold_right (fun x y -> match x with 
  (a,b,c) -> if exists (fun x -> x = a) qs && b = s then c::y else y 
  ) nfa.delta [])

let e_closure_aux (nfa: ('q,'s) nfa_t) (qs: 'q list) : 'q list =
  List.fold_right (fun x y -> match x with 
  (a,b,c) -> if (exists (fun x -> x = a) qs && not (exists (fun x -> x = c) qs) && b = None) then y @ [c] else y) nfa.delta qs

let rec e_closure (nfa: ('q,'s) nfa_t) (qs: 'q list) : 'q list =
  let states = e_closure_aux nfa qs in 
  if states <> qs then e_closure nfa states else qs

let rec accept_aux_aux (nfa: ('q,char) nfa_t) (qs: 'q list): bool = 
  let bools = List.map (fun x -> exists (fun y -> y = x) qs) nfa.fs in 
  exists (fun x -> x) bools
  
let rec accept_aux (nfa: ('q,char) nfa_t) (s: string) (qs: 'q list): bool = 
  let states = e_closure nfa qs in
  if String.length s = 0 then accept_aux_aux nfa states else 
  let states_2 = move nfa states (Some (String.get s 0)) in 
  accept_aux nfa (String.sub s 1 ((String.length s) - 1)) states_2 

let accept (nfa: ('q,char) nfa_t) (s: string) : bool =
  accept_aux nfa s [nfa.q0]

  

(*******************************)
(* Part 2: Subset Construction *)
(*******************************)


let new_states (nfa: ('q,'s) nfa_t) (qs: 'q list) : 'q list list = 
  map (fun x -> e_closure nfa (move nfa qs (Some (x)))) nfa.sigma  

let new_trans (nfa: ('q,'s) nfa_t) (qs: 'q list) : ('q list, 's) transition list =
   map (fun x -> (qs, Some (x), e_closure nfa (move nfa qs (Some (x))))) nfa.sigma

let new_finals (nfa: ('q,'s) nfa_t) (qs: 'q list) : 'q list list =
  if exists (fun x -> exists (fun y -> y = x) nfa.fs) qs then [qs] else []

let rec nfa_to_dfa_step (nfa: ('q,'s) nfa_t) (dfa: ('q list, 's) nfa_t)
    (work: 'q list list) : ('q list, 's) nfa_t =
  if length work = 0 || work = [[]] then dfa
  else let states = fold_right (fun x y -> if x <> [] then x::y else y) (new_states nfa (hd work)) [] in 
  let trans = fold_right (fun (a,b,c) y -> if c <> [] then (a,b,c)::y else y) (new_trans nfa (hd work)) [] in
  if not (exists (fun x -> exists (fun y -> y = x) states) dfa.qs) then nfa_to_dfa_step nfa {sigma = dfa.sigma; qs = union dfa.qs states; q0 = dfa.q0; fs = union dfa.fs (new_finals nfa (hd work)); delta = union dfa.delta trans} (union (tl work) states) else 
  nfa_to_dfa_step nfa {sigma = dfa.sigma; qs = dfa.qs; q0 = dfa.q0; fs = union dfa.fs (new_finals nfa (hd work)); delta = union dfa.delta trans} (tl work) 

let nfa_to_dfa (nfa: ('q,'s) nfa_t) : ('q list, 's) nfa_t =
  nfa_to_dfa_step nfa {sigma = nfa.sigma; qs = [e_closure nfa [nfa.q0]]; q0 = e_closure nfa [nfa.q0]; fs = []; delta = []} [e_closure nfa [nfa.q0]]
