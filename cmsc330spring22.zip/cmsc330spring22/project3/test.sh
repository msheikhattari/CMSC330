#! /bin/sh
. ./ocaml_version.sh
dune runtest -f
