#! /bin/sh
. ./ocaml_version.sh
dune utop src
