extern crate stark_suit_repair;

use std::collections::HashMap;

use stark_suit_repair::basics::{
    factorize, gauss, in_range, longest_sequence, mean, rotate, subset, substr, to_decimal,
};
use stark_suit_repair::communicator::{to_command, Command};

// adding linked list tests
use stark_suit_repair::linkedlist::{Armor, Component, List, Suit};

/*
 * Create a new function for each test that you want to run.  Please be sure to add
 * the #[test] attribute to each of your student tests to ensure they are all run, and
 * prefix them all with 'student_' (see example below).
 * Then, run `cargo test student` to run all of the student tests.
 */

#[test]
fn student_comm() {
    //Power str
    assert_eq!(
        "Power increased by 60%",
        Command::Power(true, 60).as_str()
    );
    assert_eq!(
        "Power decreased by 30%",
        Command::Power(false, 30).as_str()
    );
    assert_eq!(
        "Power increased by 0%",
        Command::Power(true, 0).as_str()
    );
    assert_eq!(
        "Power decreased by 0%",
        Command::Power(false, 0).as_str()
    );
    assert_eq!(
        "Not a command",
        Command::Power(true, -60).as_str()
    );
    assert_eq!(
        "Not a command",
        Command::Power(false, -30).as_str()
    );

    //Shield str
    assert_eq!(
        "Shield turned on",
        Command::Shield(true).as_str()
    );
    assert_eq!(
        "Shield turned off",
        Command::Shield(false).as_str()
    );
    assert_eq!(
        "Call attempt failed",
        Command::Try.as_str()
    );
    assert_eq!(
        "Not a command",
        Command::Invalid.as_str()
    );



    assert_eq!(
        "Missiles increased by 60",
        Command::Missiles(true, 60).as_str()
    );
    assert_eq!(
        "Missiles decreased by 30",
        Command::Missiles(false, 30).as_str()
    );






    //Power commands
    assert_eq!(Command::Power(true, 0), to_command("power inc 0"));
    assert_eq!(Command::Power(false, 0), to_command("power dec 0"));
    assert_eq!(Command::Power(true, 160), to_command("power inc 160"));
    assert_eq!(Command::Power(false, 160), to_command("power dec 160"));
    assert_eq!(Command::Invalid, to_command("Power inc -1"));
    assert_eq!(Command::Invalid, to_command("Power dec -1"));
    assert_eq!(Command::Invalid, to_command("Power"));
    assert_eq!(Command::Invalid, to_command("Power dec"));
    assert_eq!(Command::Invalid, to_command("Power inc"));
    assert_eq!(Command::Invalid, to_command("Power inc 10 now"));
    assert_eq!(Command::Invalid, to_command("Power dec 10 now"));
    assert_eq!(Command::Invalid, to_command("now Power inc 10 "));
    assert_eq!(Command::Invalid, to_command("now Power dec 10 "));

    //Missiles commands
    assert_eq!(Command::Missiles(true, 60), to_command("add 60 missiles"));
    assert_eq!(Command::Missiles(false, 30), to_command("fire    30 missiles "));
    assert_eq!(Command::Missiles(true, 0), to_command("add 0 missiles"));
    assert_eq!(Command::Missiles(false, 0), to_command("fire    0 missiles "));
    assert_eq!(Command::Invalid, to_command("add -1 missiles"));
    assert_eq!(Command::Invalid, to_command("fire    -1 missiles "));
    assert_eq!(Command::Invalid, to_command("add"));
    assert_eq!(Command::Invalid, to_command("fire"));
    assert_eq!(Command::Invalid, to_command("add 10"));
    assert_eq!(Command::Invalid, to_command("fire 10"));
    assert_eq!(Command::Invalid, to_command("add 10 missiles now"));
    assert_eq!(Command::Invalid, to_command("fire 10 missiles now"));
    assert_eq!(Command::Invalid, to_command("no add 10 missiles now"));
    assert_eq!(Command::Invalid, to_command("yes fire 10 missiles now"));

    //Shield commands
    assert_eq!(Command::Shield(false), to_command("shield off"));
    assert_eq!(Command::Shield(true), to_command("shield on"));
    assert_eq!(Command::Invalid, to_command("shield"));
    assert_eq!(Command::Invalid, to_command("shield off now"));
    assert_eq!(Command::Invalid, to_command("shield on now"));
    assert_eq!(Command::Invalid, to_command("now shield off"));
    assert_eq!(Command::Invalid, to_command("now shield on"));

    //Try command
    assert_eq!(Command::Try, to_command("  try calling Miss Potts"));
    assert_eq!(Command::Invalid, to_command("  try "));
    assert_eq!(Command::Invalid, to_command("  try calling"));
    assert_eq!(Command::Invalid, to_command("  try calling Miss"));
    assert_eq!(Command::Invalid, to_command(" now try calling Miss Potts"));
    assert_eq!(Command::Invalid, to_command("  try calling Miss Potts now"));

    

}

#[test]
fn student_repair() {
    let mut suit = Suit {
        armor: List::new(),
        version: 1,
    };

    let helm = Armor {
        component: Component::Helmet(true),
        version: 1,
    };

    let repul = Armor {
        component: Component::LeftRepulsor(true, 80),
        version: 1,
    };

    let repul2 = Armor {
        component: Component::RightRepulsor(true, 80),
        version: 1,
    };
    
    let repul3 = Armor {
        component: Component::RightRepulsor(false, 0),
        version: 1,
    };

    let repul4 = Armor {
        component: Component::RightRepulsor(false, 100),
        version: 1,
    };

    let thrust = Armor {
        component: Component::LeftThrusters(true, 88),
        version: 1,
    };

    let thrust2 = Armor {
        component: Component::RightThrusters(true, 88),
        version: 1,
    };

    let chest = Armor {
        component: Component::ChestPiece(true, 88),
        version: 1,
    };


    suit.armor.push(helm);
    suit.armor.push(thrust);
    suit.armor.push(thrust2);
    suit.armor.push(chest);
    suit.armor.push(repul);
    suit.armor.push(repul2);
    suit.armor.push(repul3);
    suit.armor.push(repul4);

    suit.repair();



    assert_eq!(
        suit.armor.peek(),
        Some(Armor {
            component: Component::RightRepulsor(false, 100),
            version: 1,
        })
    );
    
    suit.armor.pop();

    assert_eq!(
        suit.armor.peek(),
        Some(Armor {
            component: Component::RightRepulsor(false, 0),
            version: 1,
        })
    );

    suit.armor.pop();

    assert_eq!(
        suit.armor.peek(),
        Some(Armor {
            component: Component::RightRepulsor(false, 100),
            version: 1,
        })
    );

    suit.armor.pop();

    assert_eq!(
        suit.armor.peek(),
        Some(Armor {
            component: Component::LeftRepulsor(false, 100),
            version: 1,
        })
    );

    suit.armor.pop();

    assert_eq!(
        suit.armor.peek(),
        Some(Armor {
            component: Component::ChestPiece(false, 100),
            version: 1,
        })
    );

    suit.armor.pop();

    assert_eq!(
        suit.armor.peek(),
        Some(Armor {
            component: Component::RightThrusters(false, 100),
            version: 1,
        })
    );

    suit.armor.pop();

    assert_eq!(
        suit.armor.peek(),
        Some(Armor {
            component: Component::LeftThrusters(false, 100),
            version: 1,
        })
    );

    suit.armor.pop();

    assert_eq!(
        suit.armor.peek(),
        Some(Armor {
            component: Component::Helmet(true),
            version: 1,
        })
    );
}


