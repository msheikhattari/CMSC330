#![forbid(unsafe_code)]

pub mod basics;
pub mod communicator;
pub mod linkedlist;
