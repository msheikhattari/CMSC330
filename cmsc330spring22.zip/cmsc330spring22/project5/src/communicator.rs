#[derive(Debug)]
#[derive(PartialEq)]
pub enum Command
{
    Power(bool,i32),    // [Increase/Decrease] power by [number].
    Missiles(bool,i32), // [Increase/Decrease] missiles by [number].
    Shield(bool),       // Turn [On/Off] the shield.
    Try,                // Try calling pepper.
    Invalid             // [anything else]
}


/**
    Adds functionality to Command enums
    Commands can be converted to strings with the as_str method
    
    Command     |     String format
    ---------------------------------------------------------
    Power       |  /Power (increased|decreased) by [0-9]+%/
    Missiles    |  /Missiles (increased|decreased) by [0-9]+/
    Shield      |  /Shield turned (on|off)/
    Try         |  /Call attempt failed/
    Invalid     |  /Not a command/
**/
impl Command {
    pub fn as_str (&self) -> String {
        match &self {
            Command::Power(b, n) => {if *b {
                if n >= &0 {
                    let s = String::from("Power increased by ");
                    let s2 = format!("{}{}{}", s, n, "%");
                    return s2;
                }else {
                    return String::from("Not a command")
                }
            }else {
                if n >= &0 {
                    let s = String::from("Power decreased by ");
                    let s2 = format!("{}{}{}", s, n, "%");
                    return s2;
                }else {
                    return String::from("Not a command")
                }
            }},
            Command::Missiles(b, n) => {if *b {
                if n>= & 0 {
                    let s = String::from("Missiles increased by ");
                    let s2 = format!("{}{}", s, n);
                    return s2;
                }else {
                    return String::from("Not a command")
                }
            }else {
                if n>= &0 {
                    let s = String::from("Missiles decreased by ");
                    let s2 = format!("{}{}", s, n);
                    return s2;
                }else {
                    return String::from("Not a command")
                }
            }},
            Command::Shield(b) => {if *b {
                let s = String::from("Shield turned on");
                return s;
            }else {
                let s = String::from("Shield turned off");
                return s;
            }},
            Command::Try => return String::from("Call attempt failed"),
            Command::Invalid => return String::from("Not a command")
        }
    }
}

/**
    Complete this method that converts a string to a command 
    We list the format of the input strings below

    Command     |     String format
    ---------------------------------------------
    Power       |  /power (inc|dec) [0-9]+/
    Missiles    |  /(fire|add) [0-9]+ missiles/
    Shield      |  /shield (on|off)/
    Try         |  /try calling Miss Potts/
    Invalid     |  Anything else
**/

/*
pub fn to_command(s: &str) -> Command {
    let mut iter = s.split_whitespace();

    match iter.next() {
        Some(v) => {
            if v == "power" {
                match iter.next() {
                    Some(w) => if w == "inc" {
                        let b = true;
                        match iter.next() {
                            Some(x) => {
                                let n = x.parse::<u32>();
                                if n.is_err() {
                                    return Command::Invalid;
                                }else {
                                    match iter.next() {
                                        Some(y) => return Command::Invalid,
                                        None => return Command::Power(b, n.unwrap() as i32),
                                    }
                                }
                            },
                            None => return Command::Invalid,
                        }
                    }else if w == "dec" {
                        let b = false;
                        match iter.next() {
                            Some(x) => {
                                let n = x.parse::<u32>();
                                if n.is_err() {
                                    return Command::Invalid;
                                }else {
                                    match iter.next() {
                                        Some(y) => return Command::Invalid,
                                        None => return Command::Power(b, n.unwrap() as i32),
                                    }
                                }
                            },
                            None => return Command::Invalid,
                        }
                    },
                    None => return Command::Invalid,
                }
                
            }else if v == "fire"{
                let b = false;
                match iter.next(){
                    Some(x) => {
                        let n = x.parse::<u32>();
                            if n.is_err() {
                                return Command::Invalid;
                            }else {
                                match iter.next(){
                                    Some(y) => {
                                        if y == "missiles" {
                                            match iter.next() {
                                                Some(z) => return Command::Invalid,
                                                None => return Command::Missiles(b, n.unwrap() as i32)
                                            }
                                        }else{
                                            return Command::Invalid;
                                        }
                                    }
                                    None => return Command::Invalid,
                                }
                            }
                    }
                    None => return Command::Invalid,
                }
            }else if v == "add" {
                let b = true;
                match iter.next(){
                    Some(x) => {
                        let n = x.parse::<u32>();
                            if n.is_err(){
                                return Command::Invalid;
                            }else {
                                match iter.next(){
                                    Some(y) => {
                                        if y == "missiles" {
                                            match iter.next() {
                                                Some(z) => return Command::Invalid,
                                                None => return Command::Missiles(b, n.unwrap() as i32)
                                            }
                                        }else{
                                            return Command::Invalid;
                                        }
                                    }
                                    None => return Command::Invalid,
                                }
                            }
                    }
                    None => return Command::Invalid,
                }
            }else if v == "shield" {
                match iter.next() {
                    Some(x) => {
                        if x == "on" {
                            match iter.next() {
                                Some(y) => return Command::Invalid,
                                None => return Command::Shield(true),
                            }
                        }else if x == "off" {
                            match iter.next() {
                                Some(y) => return Command::Invalid,
                                None => return Command::Shield(false),
                            }
                        }else {
                            return Command::Invalid;
                        }
                    }
                    None => return Command::Invalid,
                }

            }else if v == "try" {
                match iter.next() {
                    Some(w) => {
                        if w == "calling" {
                            match iter.next() {
                                Some(x) => {
                                    if x == "Miss" {
                                        match iter.next() {
                                            Some(y) => {
                                                if y == "Potts" {
                                                    match iter.next() {
                                                        Some(z) => return Command::Invalid,
                                                        None => return Command::Try,
                                                    }
                                                }else {
                                                    return Command::Invalid;
                                                }
                                            }, 
                                            None => return Command::Invalid, 
                                        }
                                    }else {
                                        return Command::Invalid;
                                    }
                                },
                                None => return Command::Invalid,
                            }
                        }else {
                            return Command::Invalid;
                        }
                    },
                    None => return Command::Invalid,
                }
            }else {
                return Command::Invalid;
            }
        }
        None => return Command::Invalid,
    } 



    return Command::Try;
}

*/

pub fn to_command(s: &str) -> Command {
    let mut v: Vec<&str> = s.split(' ').collect();

    if v[0] == "power" {
        if v[1] == "inc" {
            let b = true;
            let n = v[2].parse::<u32>();
            if !n.is_err() {
                if v.len() == 3 {
                    return Command::Power(b,n.unwrap() as i32)
                }
            }
        }else if v[1] == "dec" {
            let b = false;
            let n = v[2].parse::<u32>();
            if !n.is_err() {
                if v.len() == 3 {
                    return Command::Power(b,n.unwrap() as i32)
                }
            }
        }
    }else if v[0] == "fire" {
        let b = false;
        let n = v[1].parse::<u32>();
        if !n.is_err() {
            if v[2] == "missiles" {
                if v.len() == 3 {
                    return Command::Missiles(b, n.unwrap() as i32)
                }
            }
        }
    }else if v[0] == "add" {
        let b = true;
        let n = v[1].parse::<u32>();
        if !n.is_err() {
            if v[2] == "missiles" {
                if v.len() == 3 {
                    return Command::Missiles(b, n.unwrap() as i32)
                }
            }
        }
    }else if v[0] == "shield" {
        if v[1] == "on" {
            let b = true;
            if v.len() == 2 {
                return Command::Shield(b);
            }
        }else if v[1] == "off" {
            let b = false;
            if v.len() == 2 {
                return Command::Shield(b);
            }
        }

    }else if v[0] == "try" {
        if v[1] == "calling" {
            if v[2] == "Miss" {
                if v[3] == "Potts" {
                    if v.len() == 4 {
                        return Command::Try
                    }
                }
            }
        }
    }
    return Command::Invalid;;
}