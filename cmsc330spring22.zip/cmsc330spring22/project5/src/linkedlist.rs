use std::{
    borrow::BorrowMut,
    ops::{Deref, DerefMut},
    sync::{Arc, RwLock},
};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Component {
    Helmet(bool),              //is damaged?
    LeftThrusters(bool, i32),  //is damaged? How much power left?
    RightThrusters(bool, i32), //is damaged? How much power left?
    LeftRepulsor(bool, i32),   //is damaged? How much power left?
    RightRepulsor(bool, i32),  //is damaged? How much power left?
    ChestPiece(bool, i32),     //is damaged? How much power left?
    Missiles(i32),             //how many missiles left?
    ArcReactor(i32),           // How much power left?
    Wifi(bool),                // connected to wifi?
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Armor {
    pub component: Component,
    pub version: i32,
}

// Part 2 
// data: Arc<RwLock<Option<Node>>>,
// Students should fill in the Link type themselves. The Node and List types are given as is.
type Link = Option<Arc<RwLock<Node>>>;

struct Node {
    data: Armor,
    rest: Link,
}

#[derive(Clone)]
pub struct List {
    head_link: Link,
    size: usize,
}

impl List {
    pub fn new() -> Self {
        List {head_link: None, size: 0}
    }

    pub fn size(&self) -> usize {
        self.size
    }

    pub fn peek(&self) -> Option<Armor> {
        match &self.head_link {
            Some (v) => Some((*v).read().unwrap().data),
            None => None,
        }
    }

    pub fn push(&mut self, component: Armor) {
        self.head_link = Some(Arc::new(RwLock::new(Node {data: component, rest: self.head_link.clone()})));
        self.size += 1;
    }

    pub fn pop(&mut self) -> Option<Armor> {
        if let None = &self.head_link {
            return None;
        }
            let ret = self.peek();
            self.size -= 1;
            self.head_link = (self.head_link.clone().unwrap()).read().unwrap().rest.clone();
            return ret;
    }
}

// Part 3

#[derive(Clone)]
pub struct Suit {
    pub armor: List,
    pub version: i32,
}

impl Suit {
    pub fn is_compatible(&self) -> bool {
        let mut suit = self.clone();

        while suit.armor.size != 0 {
            match suit.armor.pop() {
                Some (v) => {
                    if v.version != suit.version {
                        return false;
                    }
                }
                None => continue
            }
        }

        return true;
    }

    pub fn repair(&mut self) {
        let mut suit = self.clone();

        
        
        
        while suit.armor.size != 0 {
           // match suit.armor.head_link {
             //   Some(v) => {head_node = v.write().unwrap()},
               // None => continue,
           // }
            {
                let mut head_node = suit.armor.head_link.as_ref().unwrap().write().unwrap();

                match head_node.data.component {
                    Component::LeftThrusters(b, _) => {if b {
                        head_node.data.component = Component::LeftThrusters(false, 100)}},  
                    Component::RightThrusters(b, _) => {if b {
                        head_node.data.component = Component::RightThrusters(false, 100)}}, 
                    Component::LeftRepulsor(b, _) => {if b {
                        head_node.data.component = Component::LeftRepulsor(false, 100)}},   
                    Component::RightRepulsor(b, _) => {if b {
                        head_node.data.component = Component::RightRepulsor(false, 100)}}, 
                    Component::ChestPiece(b, _) => {if b {
                        head_node.data.component = Component::ChestPiece(false, 100)}},      
                    _ => {
                        head_node.data.component = head_node.data.component;
                    },         
                }
            }
            suit.armor.pop();
            //head_node = head_node.clone().rest.as_ref().unwrap().write().unwrap();
        }


        /*
            match suit.armor.head_link.as_ref().unwrap().try_read().unwrap().data.component {
                Component::LeftThrusters(b, _) => {if b {
                    suit.armor.head_link.as_ref().unwrap().try_write().unwrap().data.component = Component::LeftThrusters(false, 100)}},  
                Component::RightThrusters(b, _) => {if b {
                    suit.armor.head_link.as_ref().unwrap().try_write().unwrap().data.component = Component::RightThrusters(false, 100)}}, 
                Component::LeftRepulsor(b, _) => {if b {
                    suit.armor.head_link.as_ref().unwrap().try_write().unwrap().data.component = Component::LeftRepulsor(false, 100)}},   
                Component::RightRepulsor(b, _) => {if b {
                    suit.armor.head_link.as_ref().unwrap().try_write().unwrap().data.component = Component::RightRepulsor(false, 100)}}, 
                Component::ChestPiece(b, _) => {if b {
                    suit.armor.head_link.as_ref().unwrap().try_write().unwrap().data.component = Component::ChestPiece(false, 100)}},      
                _ => continue,         
            }
            suit.armor.pop();
            //head_node = head_node.clone().rest.as_ref().unwrap().write().unwrap();
        }*/



    }

}
