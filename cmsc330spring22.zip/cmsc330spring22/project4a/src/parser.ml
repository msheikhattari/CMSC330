open MicroCamlTypes
open Utils
open TokenTypes

(* Provided functions - DO NOT MODIFY *)

(* Matches the next token in the list, throwing an error if it doesn't match the given token *)
let match_token (toks: token list) (tok: token) =
  match toks with
  | [] -> raise (InvalidInputException(string_of_token tok))
  | h::t when h = tok -> t
  | h::_ -> raise (InvalidInputException(
      Printf.sprintf "Expected %s from input %s, got %s"
        (string_of_token tok)
        (string_of_list string_of_token toks)
        (string_of_token h)))

(* Matches a sequence of tokens given as the second list in the order in which they appear, throwing an error if they don't match *)
let match_many (toks: token list) (to_match: token list) =
  List.fold_left match_token toks to_match

(* Return the next token in the token list as an option *)
let lookahead (toks: token list) = 
  match toks with
  | [] -> None
  | h::t -> Some h

(* Return the token at the nth index in the token list as an option*)
let rec lookahead_many (toks: token list) (n: int) = 
  match toks, n with
  | h::_, 0 -> Some h
  | _::t, n when n > 0 -> lookahead_many t (n-1)
  | _ -> None

(* Part 2: Parsing expressions *)

let rec parse_expr toks =
  match (lookahead toks) with 
  | Some Tok_Let -> parse_let toks (* Let_Expr path *)
  | Some Tok_Fun -> parse_fun toks (* Function_Expr path *)
  | Some Tok_If -> parse_if toks   (* If_Expr path *)
  | Some Tok_Not | Some Tok_Int _ | Some Tok_Bool _ | Some Tok_String _ | Some Tok_ID _ | Some Tok_LParen -> parse_or toks  (* Or_Expr Path *) 
  | _ -> raise (InvalidInputException "parse_expr")
and parse_let toks = 
  match (lookahead toks) with
  | Some Tok_Let -> (let t = match_token toks Tok_Let in 
    let (t2, r) = parse_rec t in 
    match lookahead t2 with 
    | Some Tok_ID id ->
     let t3 = match_token t2 (Tok_ID id) in 
     let t4 = match_token t3 Tok_Equal in 
     let (t5, e1) = parse_expr t4 in 
     let t6 = match_token t5 Tok_In in 
     let (t7, e2) = parse_expr t6 in
     (t7, Let(id, r, e1, e2))
    | _ -> raise (InvalidInputException "Tok_ID parse_let"))
  | _ -> raise (InvalidInputException "parse_let")
and parse_rec toks =
  match (lookahead toks) with
  | Some Tok_Rec -> (match_token toks Tok_Rec, true)
  | _ -> (toks, false)

and parse_fun toks = 
  match lookahead toks with
  |Some Tok_Fun -> (let t = match_token toks Tok_Fun in
    match lookahead t with 
    |Some Tok_ID id -> let t2 = match_token t (Tok_ID id) in 
    let t3 = match_token t2 Tok_Arrow in 
    let (t4,e) = parse_expr t3 in 
    (t4, Fun(id, e))
    | _ -> raise (InvalidInputException "Tok_ID parse_fun")
  )
  | _ -> raise (InvalidInputException "parse_fun")

and parse_if toks = 
  match lookahead toks with 
  |Some Tok_If -> (let t = match_token toks Tok_If in 
    let (t2, e1) = parse_expr t in 
    let t3 = match_token t2 Tok_Then in 
    let (t4, e2) = parse_expr t3 in 
    let t5 = match_token t4 Tok_Else in 
    let (t6, e3) = parse_expr t5 in
    (t6, If(e1, e2, e3))
  )
  | _ -> raise (InvalidInputException "parse_if")

and parse_or toks = 
  let (t, a) = parse_and toks in
  match lookahead t with 
  |Some Tok_Or -> (let t2 = match_token t Tok_Or in 
                   let (t3, o) = parse_or t2 in 
                    (t3, Binop(Or, a, o)))
  | _ -> (t, a)

and parse_and toks = 
  let (t, e) = parse_eq toks  in 
  match lookahead t with 
  |Some Tok_And -> (let t2 = match_token t Tok_And in
                    let (t3, a) = parse_and t2 in
                    (t3, Binop(And, e, a)))
  | _ -> (t, e)

and parse_eq toks = 
  let (t, r) = parse_rel toks in 
  match lookahead t with 
  |Some Tok_Equal -> let t2 = match_token t Tok_Equal in 
                     let (t3, e) = parse_eq t2 in
                     (t3, Binop(Equal, r, e))
  |Some Tok_NotEqual -> let t2 = match_token t Tok_NotEqual in 
                     let (t3, e) = parse_eq t2 in
                     (t3, Binop(NotEqual, r, e))
  | _ -> (t,r)

and parse_rel toks = 
  let (t, a) = parse_add toks in 
  match lookahead t with
  |Some Tok_Less -> let t2 = match_token t Tok_Less in 
                     let (t3, r) = parse_rel t2 in 
                     (t3, Binop(Less, a, r))
  |Some Tok_Greater -> let t2 = match_token t Tok_Greater in 
                     let (t3, r) = parse_rel t2 in 
                     (t3, Binop(Greater, a, r))       
  |Some Tok_LessEqual -> let t2 = match_token t Tok_LessEqual in 
                     let (t3, r) = parse_rel t2 in 
                     (t3, Binop(LessEqual, a, r))   
  |Some Tok_GreaterEqual -> let t2 = match_token t Tok_GreaterEqual in 
                     let (t3, r) = parse_rel t2 in 
                     (t3, Binop(GreaterEqual, a, r))                                      
  | _ -> (t,a)

and parse_add toks = 
  let (t, m) = parse_mult toks in 
  match lookahead t with 
  |Some Tok_Add -> let t2 = match_token t Tok_Add in 
                   let (t3, a) = parse_add t2 in 
                   (t3, Binop(Add, m, a))
  |Some Tok_Sub -> let t2 = match_token t Tok_Sub in 
                   let (t3, a) = parse_add t2 in 
                   (t3, Binop(Sub, m, a))
  | _ -> (t, m)

and parse_mult toks = 
  let (t, c) = parse_con toks in 
  match lookahead t with 
  |Some Tok_Mult -> let t2 = match_token t Tok_Mult in
                    let (t3, m) = parse_mult t2 in 
                    (t3, Binop(Mult, c, m)) 
  |Some Tok_Div -> let t2 = match_token t Tok_Div in
                    let (t3, m) = parse_mult t2 in 
                    (t3, Binop(Div, c, m))
  | _ -> (t, c)

and parse_con toks =  
  let (t, u) = parse_un toks in
  match lookahead t with 
  |Some Tok_Concat -> let t2 = match_token t Tok_Concat in 
                      let (t3, c) = parse_con t2 in 
                      (t3, Binop(Concat, u, c))
  | _ -> (t,u)

and parse_un toks = 
  match lookahead toks with 
  |Some Tok_Not -> let t = match_token toks Tok_Not in 
                   let (t2, u) = parse_un t in 
                   (t2, Not(u))
  | _ -> parse_funcall toks

and parse_funcall toks = 
  let (t, p) = parse_primary toks in 
  match lookahead t with 
  | Some Tok_Int _ | Some Tok_Bool _ | Some Tok_String _ | Some Tok_ID _ | Some Tok_LParen -> let (t2, p2) = parse_primary t in (*Changed this to parse_funcall instead of parse_primary*)
                                                                                              (t2, (FunctionCall(p, p2))) 
  | _ -> (t, p)


and parse_primary toks = 
  match lookahead toks with 
  | Some Tok_Int n -> let t = match_token toks (Tok_Int n) in (t, Value(Int(n)))
  | Some Tok_Bool b -> let t = match_token toks (Tok_Bool b) in (t, Value(Bool b))
  | Some Tok_String s -> let t = match_token toks (Tok_String s) in (t, Value (String s))
  | Some Tok_ID s -> let t = match_token toks (Tok_ID s) in (t, ID s)
  | Some Tok_LParen -> let t = match_token toks Tok_LParen in
                       let (t2, e) = parse_expr t in 
                       let t3 = match_token t2 Tok_RParen in 
                       (t3, e)
  | _ -> raise (InvalidInputException "parse_primary")


(* Part 3: Parsing mutop *)

let rec parse_mutop toks = 
  match lookahead toks with 
  | Some Tok_DoubleSemi -> (match_token toks Tok_DoubleSemi, NoOp)
  | Some Tok_Def -> parse_mudef toks
  | _ -> parse_muexp toks

and parse_mudef toks = 
  let t = match_token toks Tok_Def in 
  match lookahead t with 
  | Some Tok_ID s -> let t2 = match_token t (Tok_ID s) in
                     let t3 = match_token t2 Tok_Equal in 
                     let (t4, e) = parse_expr t3 in 
                     let t5 = match_token t4 Tok_DoubleSemi in 
                     (t5, Def(s, e))
  | _ -> raise (InvalidInputException "parse_mudef")

and parse_muexp toks = 
  let (t, e) = parse_expr toks in
  match lookahead t with 
  |Some Tok_DoubleSemi -> (match_token t Tok_DoubleSemi, Expr e)
  | _ -> raise (InvalidInputException "parse_muexp")

















