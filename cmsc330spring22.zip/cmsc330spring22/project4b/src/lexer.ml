open TokenTypes

(* PASTE YOUR LEXER FROM P4A HERE *)

let tokenize input = failwith "unimplemented"