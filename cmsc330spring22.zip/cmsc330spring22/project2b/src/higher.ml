open Funs

(********************************)
(* Part 1: High Order Functions *)
(********************************)

let contains_elem lst e = failwith "unimplemented"

let is_present lst x = failwith "unimplemented"

let count_occ lst target = failwith "unimplemented"

let uniq lst = failwith "unimplemented"

let assoc_list lst = failwith "unimplemented"

let ap fns args = failwith "unimplemented"
