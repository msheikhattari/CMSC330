open Funs

(********************************)
(* Part 1: High Order Functions *)
(********************************)

let contains_elem lst e = 
let y = fold (fun a elm -> if e = elm then a + 1 else a) 0 lst in 
if y <> 0 then true else false

let is_present lst x = 
map (fun elm -> if x = elm then 1 else 0) lst

let count_occ lst target = 
fold (fun a elm -> if elm = target then a + 1 else a) 0 lst

let uniq lst = 
fold_right (fun elm newlst -> if contains_elem newlst elm then newlst else elm::newlst) lst []

let assoc_list lst = 
fold_right (fun elm newlst -> if contains_elem newlst (elm, count_occ lst elm) then newlst else (elm, count_occ lst elm)::newlst) lst []

let ap fns args = 
let y = map (fun f -> map f args) fns in
fold_right (fun sublst newlst -> 
fold_right (fun elm newlst -> elm::newlst) sublst newlst 
) y []