open Funs

(*************************************)
(* Part 2: Three-Way Search Tree *)
(*************************************)

type int_tree =
  | IntLeaf
  | IntNode of int * int option * int_tree * int_tree * int_tree 

let empty_int_tree = IntLeaf

let rec int_insert x t =
  match t with
  IntLeaf -> IntNode (x, None, IntLeaf, IntLeaf, IntLeaf)
  |IntNode (a, None, t1, t2, t3) -> if a > x then IntNode (x, Some a, IntLeaf, IntLeaf, IntLeaf) else if a < x then IntNode (a, Some x, IntLeaf, IntLeaf, IntLeaf) else t
  |IntNode (a, Some b, t1, t2, t3) -> if x < a then IntNode(a, Some b, int_insert x t1, t2, t3) else if x > b then IntNode(a, Some b, t1, t2, int_insert x t3) else IntNode(a, Some b, t1, int_insert x t2, t3)

let rec int_mem x t =
  match t with
  IntLeaf -> false
  |IntNode (a, None, t1, t2, t3) -> if a = x then true else false
  |IntNode (a, Some b, t1, t2, t3) -> if a = x || b = x then true else if x < a then int_mem x t1 else if x > b then int_mem x t3 else int_mem x t2

let rec int_size t =
  match t with
  IntLeaf -> 0
  |IntNode (a, None, t1, t2, t3) -> 1
  |IntNode (a, Some b, t1, t2, t3) -> 2 + int_size t1 + int_size t2 + int_size t3

let rec int_max t =
  match t with
  IntLeaf -> invalid_arg "int_max"
  |IntNode (a, None, t1, t2, t3) -> a
  |IntNode (a, Some b, t1, t2, t3) -> 
  match t3 with
  IntLeaf -> b
  |IntNode(_,_,_,_,_) -> int_max t3

(*******************************)
(* Part 3: Three-Way Search Tree-Based Map *)
(*******************************)

type 'a tree_map =
  | MapLeaf
  | MapNode of (int * 'a) * (int * 'a) option * 'a tree_map * 'a tree_map * 'a tree_map

let empty_tree_map = MapLeaf

let rec map_put k v t = 
  match t with
  MapLeaf -> MapNode ((k,v), None, MapLeaf, MapLeaf, MapLeaf)
  |MapNode ((k1,v1), None, t1, t2, t3) -> if k1 > k then MapNode ((k, v), Some (k1,v1), MapLeaf, MapLeaf, MapLeaf) else if k1 < k then MapNode ((k1,v1), Some (k,v), MapLeaf, MapLeaf, MapLeaf) else invalid_arg "map_put"
  |MapNode ((k1,v1), Some(k2,v2), t1, t2, t3) -> if k1 > k then MapNode ((k1,v1), Some(k2,v2), map_put k v t1, t2, t3) else if k2 < k then MapNode ((k1,v1), Some(k2,v2), t1, t2, map_put k v t3) else MapNode ((k1,v1), Some(k2,v2), t1, map_put k v t2, t3)

let rec map_contains k t = 
  match t with
  MapLeaf -> false
  |MapNode ((k1,_), None, t1, t2, t3) -> if k1 = k then true else false
  |MapNode ((k1,_), Some(k2,_), t1, t2, t3) -> if k1 = k || k2 = k then true else if k < k1 then map_contains k t1 else if k > k2 then map_contains k t3 else map_contains k t2

let rec map_get k t =
  match t with
  MapLeaf -> invalid_arg "map_get"
  |MapNode ((k1,v1), None, t1, t2, t3) -> if k1 = k then v1 else invalid_arg "map_get"
  |MapNode ((k1,v1), Some(k2,v2), t1, t2, t3) -> if k1 = k then v1 else if k2 = k then v2 else if k < k1 then map_get k t1 else if k > k2 then map_get k t3 else map_get k t2


(***************************)
(* Part 4: Variable Lookup *)
(***************************)

(* Modify the next line to your intended type *)
(*Most recent scope bindings at front, earlier scopes at back *)
type lookup_table = 
    | EmptyScope
    | Scope of (string * int) list * lookup_table

let empty_table : lookup_table = EmptyScope

let push_scope (table : lookup_table) : lookup_table = 
  match table with 
  EmptyScope -> Scope ([], EmptyScope)
  |Scope(lst, t) -> Scope([], Scope(lst, t))

let pop_scope (table : lookup_table) : lookup_table =
  match table with 
  EmptyScope -> failwith "No scopes remain!"
  |Scope(lst, t) -> t

let rec add_aux name lst =
  match lst with
  [] -> true
  |(h,_)::t -> if h = name then false else add_aux name t


let add_var name value (table : lookup_table) : lookup_table =
  match table with 
  EmptyScope -> failwith "There are no scopes to add a variable to!"
  |Scope(lst, t) -> if add_aux name lst then Scope( [(name, value)] @ lst, t) else failwith "Duplicate variable binding in scope!"

let rec find_var name lst = 
  match lst with 
  [] -> 0
  |(n, v)::t -> if n = name then v else find_var name t

let rec lookup name (table : lookup_table) =
  match table with 
  EmptyScope -> failwith "Variable not found!"
  |Scope(lst, t) -> if add_aux name lst = false then find_var name lst else lookup name t