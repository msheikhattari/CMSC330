# Discussion 14 - Friday, April 29<sup>th</sup>


## Recap

Last week's discussion: Box, Rc, Refcell 

## Lambda Calculus Review

Lambda calculus problems located on the 330 webpage 

Quiz is next week!

## Final Exam Review 

Practice final exams located on the 330 webpage 
