(* Introduction *)

let positive n = failwith "Not implemented"

let double x = failwith "Not implemented"

let fizz n = failwith "Not implemented"

(* Problems  *)

let first_elem lst = failwith "Not implemented"

let rec sum lst = failwith "Not implemented"

let max_list lst = failwith "Not implemented"

let sum_tuple t = failwith "Not implemented"

(* Multi-Function Problems *)

let rec product lst = failwith "Not implemented"

let rec max_product lst = failwith "Not implemented"

let rec length l = failwith "Not implemented" 

let rec check_matrix_aux lst len = failwith "Not implemented"

let check_matrix lst = failwith "Not implemented"



