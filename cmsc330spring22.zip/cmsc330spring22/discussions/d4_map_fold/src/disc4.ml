let concat lst = failwith "Not implemented"

(* Tuple concatenation *)

let concat lst = failwith "Not implemented"

(* Average *)

let length lst = failwith "Not implemented"

let sum lst = failwith "Not implemented"

let average lst = failwith "Not implemented"

(* Sentence formation *)

let sentence lst = failwith "Not implemented"

(* Index *)

let index lst elem = failwith "Not implemented"

(* Zip *)

let get_nums lst = failwith "Not implemented"

let zip a b = failwith "Not implemented"

(* List Difference *)

let diff lsta lstb = failwith "Not implemented"