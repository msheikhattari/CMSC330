open Parser

(* Evaluater *)

let rec eval (ast : expr) : int =
  failwith "unimplemented"
