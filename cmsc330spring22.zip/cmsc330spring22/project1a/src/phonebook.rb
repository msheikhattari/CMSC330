class PhoneBook
    def initialize
    end

    def add(name, number, is_listed)
        raise Exception, "Not implemented"
    end

    def lookup(name)
        raise Exception, "Not implemented"
    end

    def lookupByNum(number)
        raise Exception, "Not implemented"
    end

    def namesByAc(areacode)
        raise Exception, "Not implemented"
    end
end
